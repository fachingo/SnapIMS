"""Shopify draft integration."""
