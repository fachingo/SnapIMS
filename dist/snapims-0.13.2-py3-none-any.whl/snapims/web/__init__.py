"""SnapIMS browser application."""
